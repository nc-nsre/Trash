package com.netcompany;

import org.springframework.stereotype.Component;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Component
public class XsltProcessor {

    private final TransformerFactory transformerFactory;
    private final FileResolver fileResolver;
    private final Map<String, String> cache = new HashMap<>();

    private boolean cached = true;

    public XsltProcessor(TransformerFactory transformerFactory, FileResolver fileResolver) {
        this.transformerFactory = transformerFactory;
        this.fileResolver = fileResolver;
    }

    public synchronized void setCached(boolean cached) {
        this.cached = cached;
        if ( ! this.cached) {
            this.cache.clear();
        }
    }

    @SuppressWarnings("UnnecessaryLocalVariable")
    public String processFile(String input, String xsltFile) throws TransformerException, IOException {
        Transformer transformer = getTransformer(xsltFile);
        String result = transform(input, transformer);

        return result;
    }

    private String transform(String input, Transformer transformer) throws TransformerException {
        Source source = toSource(input);
        StringWriter stringWriter = new StringWriter();
        Result result = new StreamResult(stringWriter);
        transformer.transform(source, result);

        return stringWriter.toString();
    }

    public StreamSource toSource(String input) {
        return new StreamSource(new StringReader(input));
    }

    private Transformer getTransformer(String xsltFile) throws TransformerConfigurationException, IOException {
        String xsltFileContent = getFromCacheOrLoad(xsltFile);
        Source xslt = toSource(Objects.requireNonNull(xsltFileContent));
        Transformer transformer = this.transformerFactory.newTransformer(xslt);
        return transformer;
    }

    @SuppressWarnings("UnnecessaryLocalVariable")
    private String getFromCacheOrLoad(String xsltFile) throws IOException {
        if (this.cached && this.cache.containsKey(xsltFile)) {
            return this.cache.get(xsltFile);
        }

        String fileContent = this.fileResolver.readFileToString(xsltFile);

        return fileContent;
    }


}