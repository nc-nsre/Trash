package com.netcompany;

import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.File;
import java.io.IOException;

@Component
public class XsdSchemaValidatorFactory {
    private final SchemaFactory schemaFactory;
    private final FileResolver fileResolver;

    public XsdSchemaValidatorFactory(SchemaFactory schemaFactory, FileResolver fileResolver) {
        this.schemaFactory = schemaFactory;
        this.fileResolver = fileResolver;
    }

    public Validator getValidator(String xsdSchemaFilePath) throws IOException, SAXException {
        return getValidator(fileResolver.findFile("shiporder.xsd"));
    }

    public Validator getValidator(File xsdSchema) throws SAXException {
        return getValidator(new StreamSource(xsdSchema));
    }

    @SuppressWarnings("UnnecessaryLocalVariable")
    public Validator getValidator(Source xsdSchema) throws SAXException {
        Schema schema = schemaFactory.newSchema(xsdSchema);
        Validator validator = schema.newValidator();

        return validator;
    }
}
