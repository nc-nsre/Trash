package com.netcompany;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Component
public class FileResolver {

    public String readFileToString(String fileNameOrPath) throws IOException {
        File file = findFile(fileNameOrPath);

        String fileContent = Files.readString(file.toPath());

        return fileContent;
    }

    public File findFile(String filename) throws IOException {
        ClassPathResource resource = new ClassPathResource(filename);
        if (resource.exists() && resource.isFile()) {
            return resource.getFile();
        }

        File directFile = new File(filename);
        if (directFile.exists() && directFile.isFile()) {
            return directFile;
        }

        throw new IOException("Unable to find XSLT file at: " + filename +
                ", Current workspace directory is: " + Paths.get("").toAbsolutePath().toString());
    }
}
