package com.netcompany;

import com.ctc.wstx.api.WstxInputProperties;
import com.ctc.wstx.stax.WstxOutputFactory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.dataformat.xml.XmlFactory;
import com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import org.springframework.stereotype.Component;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


@Component
public class DataTransformer {

    private final ObjectMapper objectMapper;

    public DataTransformer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String toXml(String json) throws IOException {
        return toXml(json, null, null);
    }

    public String toXml(String json, String namespaceUri, String namespacePrefix) throws IOException {
        JsonNode node = objectMapper.readValue(json, JsonNode.class);

        node = multiRootGuard(node);
        XmlMapper xmlMapper = xmlMapper(namespaceUri, namespacePrefix);
        String xml = xmlMapper.writer().withRootName("root").writeValueAsString(node);

        return xml;
    }

    private JsonNode multiRootGuard(JsonNode node) {
        if (node.isArray()) {
            ObjectNode rootNode = objectMapper.createObjectNode();
            rootNode.withArray("item").addAll(((ArrayNode) node));
            return rootNode;
        }
        return node;
    }

    public XmlMapper xmlMapper() {
        return xmlMapper(null, null);
    }

    public XmlMapper xmlMapper(String namespaceUri, String namespacePrefix) {
        XmlMapperFeatures features = XmlMapperFeatures.builder()
                .setFeature(SerializationFeature.INDENT_OUTPUT, true)
                .setFeature(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true)
                .setFeature(ToXmlGenerator.Feature.WRITE_XML_1_1, true)
                .build();
        return xmlMapper(namespaceUri, namespacePrefix, features);
    }

    public XmlMapper xmlMapper(String namespaceUri, String namespacePrefix, XmlMapperFeatures xmlMapperFeatures) {
        XmlMapper xmlMapper = getXmlMapperWithFactory(namespaceUri, namespacePrefix);

        xmlMapperFeatures.deserializeFeatures.forEach(xmlMapper::configure);
        xmlMapperFeatures.generatorFeatures.forEach(xmlMapper::configure);
        xmlMapperFeatures.serializeFeatures.forEach(xmlMapper::configure);

        return xmlMapper;
    }

    private XmlMapper getXmlMapperWithFactory(String namespaceUri, String namespacePrefix) {
        if (namespaceUri != null && namespacePrefix != null) {
            XmlFactory xmlFactory = XmlFactory.builder().xmlOutputFactory(new WstxOutputFactory() {
                @Override
                public XMLStreamWriter createXMLStreamWriter(Writer w) throws XMLStreamException {
                    mConfig.setProperty(WstxInputProperties.P_RETURN_NULL_FOR_DEFAULT_NAMESPACE, true);
                    mConfig.enableAutomaticNamespaces(true);
                    XMLStreamWriter result = super.createXMLStreamWriter(w);
                    result.setPrefix(namespacePrefix, namespaceUri);
                    return result;
                }
            }).build();

            return new XmlMapper(xmlFactory);
        }
        return new XmlMapper();
    }

    public static class XmlMapperFeatures {
        private final Map<ToXmlGenerator.Feature, Boolean> generatorFeatures;
        private final Map<SerializationFeature, Boolean> serializeFeatures;
        private final Map<DeserializationFeature, Boolean> deserializeFeatures;

        private XmlMapperFeatures(Map<ToXmlGenerator.Feature, Boolean> generatorFeatures,
                                  Map<SerializationFeature, Boolean> serializeFeatures,
                                  Map<DeserializationFeature, Boolean> deserializeFeatures) {
            this.generatorFeatures = Collections.unmodifiableMap(generatorFeatures);
            this.serializeFeatures = Collections.unmodifiableMap(serializeFeatures);
            this.deserializeFeatures = Collections.unmodifiableMap(deserializeFeatures);
        }

        public static XmlMapperFeaturesBuilder builder() {
            return new XmlMapperFeaturesBuilder();
        }

        public static class XmlMapperFeaturesBuilder {
            private Map<ToXmlGenerator.Feature, Boolean> generatorFeatures = new HashMap<>();
            private Map<SerializationFeature, Boolean> serializeFeatures = new HashMap<>();
            private Map<DeserializationFeature, Boolean> deserializeFeatures = new HashMap<>();

            private XmlMapperFeaturesBuilder() {}

            public XmlMapperFeaturesBuilder setFeature(ToXmlGenerator.Feature feature, Boolean bool) {
                generatorFeatures.put(feature, bool);
                return this;
            }

            public XmlMapperFeaturesBuilder setFeature(SerializationFeature feature, Boolean bool) {
                serializeFeatures.put(feature, bool);
                return this;
            }

            public XmlMapperFeaturesBuilder setFeature(DeserializationFeature feature, Boolean bool) {
                deserializeFeatures.put(feature, bool);
                return this;
            }

            public XmlMapperFeatures build() {
                return new XmlMapperFeatures(generatorFeatures, serializeFeatures, deserializeFeatures);
            }
        }
    }
}
