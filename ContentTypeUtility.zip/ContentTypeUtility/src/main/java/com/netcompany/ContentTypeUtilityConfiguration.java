package com.netcompany;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.saxon.BasicTransformerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.xml.XMLConstants;
import javax.xml.transform.TransformerFactory;
import javax.xml.validation.SchemaFactory;

/**
 * The XsltProcessorConfiguration imports the classes for the XML and JSON manipulation
 * and validation
 *
 * The configuration also holds a few dependencies used within the components, that can
 * be overriden by simply supplying the classes in the spring context.
 */
@Configuration
@Import({ XsltProcessor.class, FileResolver.class, OpenApiValidatorFactory.class, DataTransformer.class, XsdSchemaValidatorFactory.class })
public class ContentTypeUtilityConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public TransformerFactory transformerFactory() {
        return new BasicTransformerFactory();
    }

    @Bean
    @ConditionalOnMissingBean
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();

        return objectMapper;
    }

    @Bean
    @ConditionalOnMissingBean
    public SchemaFactory schemaFactory() {
        SchemaFactory schemaFactory = SchemaFactory
                .newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        return schemaFactory;
    }
}
