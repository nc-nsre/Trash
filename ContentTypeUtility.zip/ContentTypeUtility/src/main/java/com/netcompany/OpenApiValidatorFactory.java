package com.netcompany;

import org.openapi4j.core.exception.EncodeException;
import org.openapi4j.core.exception.ResolutionException;
import org.openapi4j.core.validation.ValidationException;
import org.openapi4j.parser.OpenApi3Parser;
import org.openapi4j.parser.model.v3.OpenApi3;
import org.openapi4j.parser.model.v3.Schema;
import org.openapi4j.schema.validator.ValidationContext;
import org.openapi4j.schema.validator.v3.SchemaValidator;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

@Component
public class OpenApiValidatorFactory {

    private final FileResolver fileResolver;

    public OpenApiValidatorFactory(FileResolver fileResolver) {
        this.fileResolver = fileResolver;
    }

    public SchemaValidator loadSchemaValidator(String schemaFilename, String schemaName) throws IOException, ResolutionException, ValidationException, EncodeException {
        return loadSchemaValidator(fileResolver.findFile(schemaFilename), schemaName);
    }

    public SchemaValidator loadSchemaValidator(File file, String schemaName) throws ResolutionException, ValidationException, EncodeException {
        OpenApi3 api = new OpenApi3Parser().parse(file, true);
        Schema schema = api.getComponents().getSchema(schemaName);

        SchemaValidator schemaValidator = new SchemaValidator(new ValidationContext<>(api.getContext()), null, schema.toNode());

        return schemaValidator;
    }
}
