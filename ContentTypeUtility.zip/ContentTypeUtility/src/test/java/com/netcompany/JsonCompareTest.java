package com.netcompany;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openapi4j.core.exception.EncodeException;
import org.openapi4j.core.exception.ResolutionException;
import org.openapi4j.core.validation.ValidationException;
import org.openapi4j.schema.validator.v3.SchemaValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

@SpringBootTest(classes = ContentTypeUtilityConfiguration.class)
@RunWith(SpringRunner.class)
public class JsonCompareTest {

    @Autowired
    public ObjectMapper objectMapper;

    @Autowired
    OpenApiValidatorFactory openApiValidatorFactory;

    @Autowired
    public FileResolver fileResolver;

    @Test
    public void testCompareJsonInvalid() throws IOException, ResolutionException, ValidationException, EncodeException {
        String json01 = fileResolver.readFileToString("pets01.json");
        String json02 = fileResolver.readFileToString("pets02.json");

        JsonNode node01 = objectMapper.readValue(json01, JsonNode.class);
        JsonNode node02 = objectMapper.readValue(json02, JsonNode.class);

        SchemaValidator schemaValidator = openApiValidatorFactory.loadSchemaValidator("petstore.json", "Pets");
        schemaValidator.validate(node01);
        schemaValidator.validate(node02);

        Assert.assertNotEquals(node01, node02);
    }

    @Test
    public void testCompareJsonValid() throws IOException, ResolutionException, ValidationException, EncodeException {
        String json01 = fileResolver.readFileToString("pets01.json");
        String json02 = fileResolver.readFileToString("pets03.json");

        JsonNode node01 = objectMapper.readValue(json01, JsonNode.class);
        JsonNode node02 = objectMapper.readValue(json02, JsonNode.class);

        SchemaValidator schemaValidator = openApiValidatorFactory.loadSchemaValidator("petstore.json", "Pets");
        schemaValidator.validate(node01);
        schemaValidator.validate(node02);

        Assert.assertEquals(node01, node02);
    }

}
