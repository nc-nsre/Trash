package com.netcompany;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.xml.sax.SAXException;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;

import javax.xml.transform.TransformerException;
import javax.xml.validation.Validator;
import java.io.IOException;

@SpringBootTest(classes = {ContentTypeUtilityConfiguration.class})
@RunWith(SpringRunner.class)
public class XsltProcessorTest {

    private final static String XSLT_FILE = "shiporder.xslt";
    private final static boolean OUTPUT_XML = false;

    @Autowired
    public XsltProcessor xsltProcessor;
    @Autowired
    public FileResolver fileResolver;

    @Autowired
    public XsdSchemaValidatorFactory xsdSchemaValidatorFactory;

    public XsltProcessorTest() {
    }

    @Test
    public void testAnyRun()
            throws IOException, TransformerException, SAXException {
        String inputXml = fileResolver.readFileToString("shiporder_01.xml");
        String result = xsltProcessor.processFile(inputXml, XSLT_FILE);
        String expectedResult = fileResolver.readFileToString("shiporder_01_expected.xml");


        Diff diff = DiffBuilder.compare(expectedResult)
                .withTest(result)
                .checkForSimilar()
                .ignoreWhitespace()
                .build();

        if (OUTPUT_XML) {
            System.out.println("========= EXPECTED =========");
            System.out.println(expectedResult);
            System.out.println("=========  ACTUAL  =========");
            System.out.println(result);
        }

        Validator validator = xsdSchemaValidatorFactory.getValidator("shiporder.xsd");
        validator.validate(xsltProcessor.toSource(expectedResult));
        validator.validate(xsltProcessor.toSource(result));

        if (diff.hasDifferences()) {
            Assert.fail(diff.fullDescription());
        }
    }
}
