package com.netcompany;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

@SpringBootTest(classes = ContentTypeUtilityConfiguration.class)
@RunWith(SpringRunner.class)
public class TransformationTest {

    @Autowired
    DataTransformer dataTransformer;

    @Autowired
    public FileResolver fileResolver;

    @Test
    public void testTransformationMultiRoot() throws IOException {
        String json01 = fileResolver.readFileToString("pets01.json");
        String xml = dataTransformer.toXml(json01);

        System.out.println(xml);
    }

    @Test
    public void testTransformationInnerArray() throws IOException {
        String json01 = fileResolver.readFileToString("owner.json");
        String xml = dataTransformer.toXml(json01);

        System.out.println(xml);
    }
}
